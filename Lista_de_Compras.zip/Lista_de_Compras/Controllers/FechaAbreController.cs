﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Lista_de_Compras.Models;
using Microsoft.AspNetCore.Mvc;
using ReflectionIT.Mvc.Paging;
using Lista_de_Compras.Context;
using Microsoft.EntityFrameworkCore;
using Lista_de_Compras.ViewModels;
using System.Data.SqlClient;
using System.Data.Entity;
using LinqToDB;
using SqlCommand = Microsoft.Data.SqlClient.SqlCommand;
using SqlConnection = Microsoft.Data.SqlClient.SqlConnection;
using EntityState = Microsoft.EntityFrameworkCore.EntityState;
using static LinqToDB.Common.Configuration;
using System.Data;
namespace Lista_de_Compras.Controllers
{
    public class FechaAbreController : Controller
    {
        private readonly AppDbContext _context;


        public FechaAbreController(AppDbContext context)
        {
            _context = context;
        }
        // GET: FechaAbreController
        public ActionResult Index()
        {
            return View();
        }

        // GET: FechaAbreController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: FechaAbreController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: FechaAbreController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        public async Task<IActionResult> Fecha(int? id)
        {
            if (id == null || _context.Compra == null)
            {
                return NotFound();
            }

            var compra = await _context.Compra.FindAsync(id);
            if (compra == null)
            {
                return NotFound();
            }
            return View(compra);
        }

        // POST: Compras/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
  
        public IActionResult Fecha(int id, [Bind("CompraNumero, CompraSituacao")] Compra compra)
        {
            if (id != compra.CompraNumero)
            {
                return NotFound();
            }


            var parameter = new List<SqlParameter>();

            parameter.Add(new SqlParameter("@CompraNumero", compra.CompraNumero));




            var result = Task.Run(async () => await _context.Database
           .ExecuteSqlRawAsync(@"exec dbo.sp_UpdateCompra @CompraNumero", parameter.ToArray()));




            return RedirectToAction("Index", "Compra");

        }

        public async Task<IActionResult> Edit(int? id)
        {
            var compra1 = _context.Compra
                .Where(p => p.CompraSituacao.Contains("Fechado"))
               .Where(a => a.CompraNumero == id)

               .FirstOrDefault();
               
           
            if (compra1 != null)
            {
                return RedirectToAction("Index", "Compra");
            }


            ViewData["Fechado"] = "Fechado";

            if (id == null || _context.Compra == null)
            {
                return NotFound();
            }

            var compra = await _context.Compra.FindAsync(id);
            if (compra == null)
            {
                return NotFound();
            }
            return View(compra);
        }

        // POST: Compras/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit([Bind("CompraNumero,CompraTitulo,CompraData, CompraSituacao")] Compra compra, string query)
        {

            

            _context.Update(compra);
                    await _context.SaveChangesAsync();



            return RedirectToAction("Index", "Compra");
        }
        // GET: FechaAbreController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: FechaAbreController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        private bool CompraExists(int id)
        {
            return _context.Compra.Any(e => e.CompraNumero == id);
        }

    }
}
