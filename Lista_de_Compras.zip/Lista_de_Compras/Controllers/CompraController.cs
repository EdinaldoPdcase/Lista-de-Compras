﻿using Lista_de_Compras.Models;
using Microsoft.AspNetCore.Mvc;
using ReflectionIT.Mvc.Paging;
using Lista_de_Compras.Context;
using Microsoft.EntityFrameworkCore;
using Lista_de_Compras.ViewModels;
using Microsoft.Data.SqlClient;
using System.Data.Entity;
using LinqToDB;
using SqlCommand = Microsoft.Data.SqlClient.SqlCommand;
using SqlConnection = Microsoft.Data.SqlClient.SqlConnection;
using EntityState = Microsoft.EntityFrameworkCore.EntityState;
using static LinqToDB.Common.Configuration;
using System.Data;

namespace Lista_de_Compras.Controllers
{
    public class CompraController : Controller
    {
        private readonly AppDbContext _context;
       

        public CompraController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Compras
        public async Task<IActionResult> Index(int page = 1)
        {
            var qry = _context.Compra.OrderBy(p => p.CompraNumero);
            var model = await PagingList.CreateAsync(qry, 10, page);
            return View(model);
        }


        /*
         *  public IActionResult Index()
        {
            var qry = _context.Compra.OrderBy(p => p.CompraNumero).ToList();
            
            return View(qry);
        }
         * 
         * public async Task<IActionResult> Index()

        {
            return View(await _context.Compra.ToListAsync());
        }*/

        // GET: Compras/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Compras/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateAsync([Bind("CompraTitulo")] Compra compra)
        {

            //var compra = await _context.Produto.FirstOrDefaultAsync(m => m.ProdutoID == ProdutoID);
            var parameter = new List<SqlParameter>();
            parameter.Add(new SqlParameter("@TituloCompra", compra.CompraTitulo));
           


            var result = await Task.Run(() => _context.Database
           .ExecuteSqlRawAsync(@"exec  dbo.sp_InsereCompra @TituloCompra", parameter.ToArray()));

            
            return RedirectToAction("Index");

        }

       
        
        public int GetNum(int CompraNumero) {

            return CompraNumero;
        }
        public IActionResult Cria(int id, string Filter)
        {
            ViewData["id"] = id;
            ViewData["filter"] = Filter;
            if (id == 0)
            {
                return NotFound();
            }
            CompraListViewModel ProdutoVM = new CompraListViewModel();
            if (string.IsNullOrWhiteSpace(Filter))
            {



                var ProdutoPesquisa = from n in _context.Produto
                                      where ((ProdutoVM.ProdutoNome == null) || (n.ProdutoNome == n.ProdutoNome.Trim()))
                                                                       && ((ProdutoVM.ProdutoUnidade == null) || (n.ProdutoUnidade == n.ProdutoUnidade.Trim()))
                                      select new
                                      {

                                          ProdutoNome = n.ProdutoNome,
                                          ProdutoUnidade = n.ProdutoUnidade

                                      };
                List<Produto> listaCompra = new List<Produto>();
                foreach (var reg in ProdutoPesquisa)
                {
                    Produto produto_campo = new Produto();
                    produto_campo.ProdutoNome = reg.ProdutoNome;
                    produto_campo.ProdutoUnidade = reg.ProdutoUnidade;
                    listaCompra.Add(produto_campo);
                }
                ProdutoVM.Produtos = listaCompra;

            }
            else
            {

                var ProdutoNom = _context.Produto.Where(p => p.ProdutoNome.Contains(Filter));





                var ProdutoPesquisa = from n in _context.Produto.Where(p => p.ProdutoNome.Contains(Filter))

                                      where ((ProdutoVM.ProdutoNome == null) || (n.ProdutoNome == n.ProdutoNome.Trim()))
                                                                                             && ((ProdutoVM.ProdutoUnidade == null) || (n.ProdutoUnidade == n.ProdutoUnidade.Trim()))
                                      select new
                                      {

                                          ProdutoNome = n.ProdutoNome,
                                          ProdutoUnidade = n.ProdutoUnidade,


                                      };
                List<Produto> listaCompra = new List<Produto>();
                foreach (var reg in ProdutoPesquisa)
                {
                    Produto produto_campo = new Produto();
                    produto_campo.ProdutoNome = reg.ProdutoNome;
                    produto_campo.ProdutoUnidade = reg.ProdutoUnidade;

                    listaCompra.Add(produto_campo);
                }
                ProdutoVM.Produtos = listaCompra;
            }


            return View(ProdutoVM);


        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Cria(int id, string ProdutoNome, int CompraItensQtd)
        {

            //var compra = await _context.Produto.FirstOrDefaultAsync(m => m.ProdutoID == ProdutoID);
            var parameter = new List<SqlParameter>();
            parameter.Add(new SqlParameter("@CompraNumero", id));
            parameter.Add(new SqlParameter("@ProdutoNome", ProdutoNome));
            parameter.Add(new SqlParameter("@CompraItensQtd", CompraItensQtd));


            var result = await Task.Run(() => _context.Database
           .ExecuteSqlRawAsync(@"exec sp_Insere_Produto @CompraNumero, @ProdutoNome, @CompraItensQtd", parameter.ToArray()));

            return RedirectToAction("Index");

        }

        /*
        public IActionResult CriaFim(int id, string Filter, int CompraItensQtd)
        {
           
            ViewData["id"] = id;
            ViewData["filter"] = Filter;
            var parameter = new List<SqlParameter>();
            parameter.Add(new SqlParameter("@CompraNumero", id));
            parameter.Add(new SqlParameter("@ProdutoNome", Filter));
            parameter.Add(new SqlParameter("@CompraItensQtd", CompraItensQtd));

            
            var result = Task.Run(() => _context.Database
           .ExecuteSqlRawAsync(@"exec  dbo.sp_Insere_Produto @CompraNumero, @ProdutoNome, @CompraItensQtd", parameter.ToArray()));
            CompraListViewModel ProdutoVM = new CompraListViewModel();
            if (string.IsNullOrWhiteSpace(Filter))
            {



                var ProdutoPesquisa = from n in _context.Produto
                                      where ((ProdutoVM.ProdutoNome == null) || (n.ProdutoNome == n.ProdutoNome.Trim()))
                                                                       && ((ProdutoVM.ProdutoUnidade == null) || (n.ProdutoUnidade == n.ProdutoUnidade.Trim()))
                                      select new
                                      {

                                          ProdutoNome = n.ProdutoNome,
                                          ProdutoUnidade = n.ProdutoUnidade

                                      };
                List<Produto> listaCompra = new List<Produto>();
                foreach (var reg in ProdutoPesquisa)
                {
                    Produto produto_campo = new Produto();
                    produto_campo.ProdutoNome = reg.ProdutoNome;
                    produto_campo.ProdutoUnidade = reg.ProdutoUnidade;
                    listaCompra.Add(produto_campo);
                }
                ProdutoVM.Produtos = listaCompra;

            }
            else
            {

                var ProdutoNom = _context.Produto.Where(p => p.ProdutoNome.Contains(Filter));





                var ProdutoPesquisa = from n in _context.Produto.Where(p => p.ProdutoNome.Contains(Filter))

                                      where ((ProdutoVM.ProdutoNome == null) || (n.ProdutoNome == n.ProdutoNome.Trim()))
                                                                                             && ((ProdutoVM.ProdutoUnidade == null) || (n.ProdutoUnidade == n.ProdutoUnidade.Trim()))
                                      select new
                                      {

                                          ProdutoNome = n.ProdutoNome,
                                          ProdutoUnidade = n.ProdutoUnidade,


                                      };
                List<Produto> listaCompra = new List<Produto>();
                foreach (var reg in ProdutoPesquisa)
                {
                    Produto produto_campo = new Produto();
                    produto_campo.ProdutoNome = reg.ProdutoNome;
                    produto_campo.ProdutoUnidade = reg.ProdutoUnidade;

                    listaCompra.Add(produto_campo);
                }
                ProdutoVM.Produtos = listaCompra;
            }

            
            return View(ProdutoVM);


        }

        // POST: Compras/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
       
        public IActionResult Cria(int id, string Filter)
        {
            ViewData["id"] = id;
            ViewData["filter"] = Filter;
            if (id == 0)
            {
                return NotFound();
            }
            CompraListViewModel ProdutoVM = new CompraListViewModel();
            if (string.IsNullOrWhiteSpace(Filter))
            {



                var ProdutoPesquisa = from n in _context.Produto
                                      where ((ProdutoVM.ProdutoNome == null) || (n.ProdutoNome == n.ProdutoNome.Trim()))
                                                                       && ((ProdutoVM.ProdutoUnidade == null) || (n.ProdutoUnidade == n.ProdutoUnidade.Trim()))
                                      select new
                                      {

                                          ProdutoNome = n.ProdutoNome,
                                          ProdutoUnidade = n.ProdutoUnidade

                                      };
                List<Produto> listaCompra = new List<Produto>();
                foreach (var reg in ProdutoPesquisa)
                {
                    Produto produto_campo = new Produto();
                    produto_campo.ProdutoNome = reg.ProdutoNome;
                    produto_campo.ProdutoUnidade = reg.ProdutoUnidade;
                    listaCompra.Add(produto_campo);
                }
                ProdutoVM.Produtos = listaCompra;

            }
            else
            {

                var ProdutoNom = _context.Produto.Where(p => p.ProdutoNome.Contains(Filter));





                var ProdutoPesquisa = from n in _context.Produto.Where(p => p.ProdutoNome.Contains(Filter))

                                      where ((ProdutoVM.ProdutoNome == null) || (n.ProdutoNome == n.ProdutoNome.Trim()))
                                                                                             && ((ProdutoVM.ProdutoUnidade == null) || (n.ProdutoUnidade == n.ProdutoUnidade.Trim()))
                                      select new
                                      {

                                          ProdutoNome = n.ProdutoNome,
                                          ProdutoUnidade = n.ProdutoUnidade,


                                      };
                List<Produto> listaCompra = new List<Produto>();
                foreach (var reg in ProdutoPesquisa)
                {
                    Produto produto_campo = new Produto();
                    produto_campo.ProdutoNome = reg.ProdutoNome;
                    produto_campo.ProdutoUnidade = reg.ProdutoUnidade;

                    listaCompra.Add(produto_campo);
                }
                ProdutoVM.Produtos = listaCompra;
            }


            return View(ProdutoVM);


        }
        [HttpPost, ActionName("Cria")]
        [ValidateAntiForgeryToken]
        public IActionResult Cria(int id, string Filter, int CompraItensQtd)
        {
            
            CompraListViewModel ProdutoVM = new CompraListViewModel();

            if (string.IsNullOrWhiteSpace(Filter))
            {



                var ProdutoPesquisa = from n in _context.Produto
                                      where ((ProdutoVM.ProdutoNome == null) || (n.ProdutoNome == n.ProdutoNome.Trim()))
                                                                       && ((ProdutoVM.ProdutoUnidade == null) || (n.ProdutoUnidade == n.ProdutoUnidade.Trim()))
                                      select new
                                      {

                                          ProdutoNome = n.ProdutoNome,
                                          ProdutoUnidade = n.ProdutoUnidade

                                      };
                List<Produto> listaCompra = new List<Produto>();
                foreach (var reg in ProdutoPesquisa)
                {
                    Produto produto_campo = new Produto();
                    produto_campo.ProdutoNome = reg.ProdutoNome;
                    produto_campo.ProdutoUnidade = reg.ProdutoUnidade;
                    listaCompra.Add(produto_campo);
                }
                ProdutoVM.Produtos = listaCompra;

            }
            else
            {

                var ProdutoNom = _context.Produto.Where(p => p.ProdutoNome.Contains(Filter));





                var ProdutoPesquisa = from n in _context.Produto.Where(p => p.ProdutoNome.Contains(Filter))

                                      where ((ProdutoVM.ProdutoNome == null) || (n.ProdutoNome == n.ProdutoNome.Trim()))
                                                                                             && ((ProdutoVM.ProdutoUnidade == null) || (n.ProdutoUnidade == n.ProdutoUnidade.Trim()))
                                      select new
                                      {

                                          ProdutoNome = n.ProdutoNome,
                                          ProdutoUnidade = n.ProdutoUnidade,


                                      };
                List<Produto> listaCompra = new List<Produto>();
                foreach (var reg in ProdutoPesquisa)
                {
                    Produto produto_campo = new Produto();
                    produto_campo.ProdutoNome = reg.ProdutoNome;
                    produto_campo.ProdutoUnidade = reg.ProdutoUnidade;

                    listaCompra.Add(produto_campo);
                }
                ProdutoVM.Produtos = listaCompra;
            }

            var parameter = new List<SqlParameter>();
            parameter.Add(new SqlParameter("@CompraNumero", id));
            parameter.Add(new SqlParameter("@ProdutoNome", Filter));
            parameter.Add(new SqlParameter("@CompraItensQtd", CompraItensQtd));


            var result = Task.Run(() => _context.Database
           .ExecuteSqlRawAsync(@"exec sp_Insere_Produto @CompraNumero, @ProdutoNome, @CompraItensQtd", parameter.ToArray()));
            
            return View(ProdutoVM);







        }

        */



        // POST: Compras/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.



        // GET: Compras/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Compra == null)
            {
                return NotFound();
            }

            var compra = await _context.Compra
                .FirstOrDefaultAsync(m => m.CompraNumero == id);
            if (compra == null)
            {
                return NotFound();
            }

            return View(compra);
        }

        // GET: Compras/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            var compra1 = _context.Compra
                .Where(p => p.CompraSituacao.Contains("Fechado"))
               .Where(a => a.CompraNumero == id)

               .FirstOrDefault();


            if (compra1 != null)
            {
                return RedirectToAction("Index", "Compra");
            }

            if (id == null || _context.Compra == null)
            {
                return NotFound();
            }

            var compra = await _context.Compra.FindAsync(id);
            if (compra == null)
            {
                return NotFound();
            }
            return View(compra);
        }

        // POST: Compras/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CompraNumero,CompraTitulo,CompraData, CompraSituacao")] Compra compra)
        {
            if (id != compra.CompraNumero)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(compra);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CompraExists(compra.CompraNumero))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(compra);
        }

        // GET: Compras/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Compra == null)
            {
                return NotFound();
            }

            var compra = await _context.Compra
                .FirstOrDefaultAsync(m => m.CompraNumero == id);
            if (compra == null)
            {
                return NotFound();
            }

            return View(compra);
        }

        // POST: Compras/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Compra == null)
            {
                return Problem("Entity set 'AppDbContext.Compra'  is null.");
            }
            var compra = await _context.Compra.FindAsync(id);
            if (compra != null)
            {
                _context.Compra.Remove(compra);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CompraExists(int id)
        {
            return _context.Compra.Any(e => e.CompraNumero == id);
        }

    }
}


/*
 * 
 * 
  
*/