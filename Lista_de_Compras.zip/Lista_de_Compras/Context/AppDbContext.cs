﻿using Lista_de_Compras.Models;
using Lista_de_Compras.ViewModels;
using Microsoft.EntityFrameworkCore;


namespace Lista_de_Compras.Context
{
    public class AppDbContext : DbContext
    {
        
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        { }
        public virtual DbSet<Compra> Compra { get; set; }
        public virtual DbSet<CompraItens> CompraItens { get; set; }
        public virtual DbSet<Produto> Produto { get; set; }

       
    }
}


