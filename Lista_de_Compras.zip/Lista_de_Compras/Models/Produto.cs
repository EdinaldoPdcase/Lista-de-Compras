﻿using LinqToDB.Mapping;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections;
using System.ComponentModel.DataAnnotations;

namespace Lista_de_Compras.Models
{
    public class Produto
    {
        [Key]
        [Identity]
        public int ProdutoID { get; set; }
        [Display(Name = "Nome do Produto")]
        [Required(ErrorMessage = "Informe o nome do Produto")]
        [StringLength(100, ErrorMessage = "O tamanho máximo é 100 caracteres")]
        public string ProdutoNome { get; set; }
        [Display(Name = "Valor Unitario")]
        [System.ComponentModel.DataAnnotations.DataType(DataType.Currency)]
        [System.ComponentModel.DataAnnotations.Schema.Column(TypeName = "decimal(28,2)")]
        public decimal ProdutoValorUnitario { get; set; }
        [Display(Name = "Unidade")]
        [Required(ErrorMessage = "Informe a quantidade do item da compra")]
        [StringLength(3, ErrorMessage = "O tamanho máximo é 200 caracteres")]
        public string ProdutoUnidade { get; set; }
        
        public virtual List<CompraItens> CompraItens { get; set; }
        
      
    }
}