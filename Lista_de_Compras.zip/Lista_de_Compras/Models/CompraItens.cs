﻿using Lista_de_Compras.ViewModels;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lista_de_Compras.Models
{
    [PrimaryKey(nameof(CompraNumero), nameof(ProdutoID))]
    public class CompraItens
    {
        public int ProdutoID { get; set; }
        public int CompraNumero { get; set; }
        
        [Display(Name = "Quantidade")]
        [Required(ErrorMessage = "Informe a quantidade do item da compra")]
        public int CompraItensQtd { get; set; }
        [DataType(DataType.Currency)]
        [Column(TypeName = "decimal(28,2)")]
        public decimal CompraItensTotal { get; set; }


        public virtual Produto Produto { get; set; }



    }
}