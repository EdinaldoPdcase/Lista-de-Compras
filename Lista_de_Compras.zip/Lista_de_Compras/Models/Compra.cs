﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lista_de_Compras.Models
{
    public class Compra
    {
        [Key]
        public int CompraNumero { get; set; }
        [Display(Name = "Título da compra")]
        [Required(ErrorMessage = "Informe um título da compra")]
        [StringLength(100, ErrorMessage = "O tamanho máximo é 100 caracteres")]
        public string CompraTitulo { get; set; }
        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public System.DateTime CompraData { get; set; }
        [DataType(DataType.Currency)]
        [Column(TypeName = "decimal(28,2)")]
        public int CompraTotal { get; set; } 
        public string CompraSituacao { get; set; }

      

    }
}