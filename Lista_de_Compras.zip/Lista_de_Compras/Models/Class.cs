﻿namespace Lista_de_Compras.Models
{
    public class Class
    {
    }
}
