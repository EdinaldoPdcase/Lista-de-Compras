﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace Lista_de_Compras.Models
{
    public class Entidades
    {
        public class Compra
        {
            public int CompraNumero { get; set; }
        }
        [PrimaryKey(nameof(CompraNumero), nameof(ProdutoID))]
        public class CompraItens
        {
            public int ProdutoID { get; set; }
            public int CompraNumero { get; set; }
            public int CompraItensQtd { get; set; }
        }
        
        public class Produto
        {
            public int ProdutoID { get; set; }

            public string ProdutoNome { get; set; }
        }

        
    }
}
