﻿using Lista_de_Compras.Models;

namespace Lista_de_Compra.Repositories.Interfaces
{
    public class IProdutoCrud
    {
        public IEnumerable<Produto> Produtos { get; }

        public Produto GetFiltraProduto { get; set; }
        public Produto GetProdutoById { get; set; }
        public int SalvaProduto { get; }
        public Produto ProdutoDeleta { get; }

        public Produto AtualizaProduto { get; set; }
    }
}

