﻿using Lista_de_Compras.Models;

namespace Lista_de_Compra.Repositories.Interfaces
{
    public class IComprasItens
    {
        public IEnumerable<IComprasItens> ComprasItens { get; }

        public IEnumerable<CompraItens> CompraMetodo { get; set; }
        public IComprasItens GetFiltraComprasItens { get; set; }

        public IComprasItens SalvaComprasItens { get; set; }

        public IComprasItens ComprasItensDeleta { get; }

        public IComprasItens AtualizaComprasItens { get; set; }
    }
}
