﻿

using Lista_de_Compras.Models;

namespace Lista_de_Compra.Repositories.Interfaces
{
    public class ICompraCrud
    {
        public IEnumerable<Compra> Compras { get; }


        public Compra GetFiltraCompra { get; set; }

        public Compra SalvaCompra { get; }
        public Compra CompraDeleta { get; }

        public Compra AtualizaCompra { get; set; }
    }
}
