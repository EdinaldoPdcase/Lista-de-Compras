﻿using Lista_de_Compra.Repositories.Interfaces;
using Lista_de_Compras.Context;
using Lista_de_Compras.Models;
using Microsoft.EntityFrameworkCore;
using System.Data.SqlClient;

namespace Lista_de_Compra.Repositories
{

    public class CompraCrud : ICompraCrud
    {

        public readonly AppDbContext db;
        public CompraCrud(AppDbContext contexto)
        {
            db = contexto;
        }
#pragma warning disable CS0108 // O membro oculta o membro herdado; nova palavra-chave ausente
        public IEnumerable<Compra> Compras()
#pragma warning restore CS0108 // O membro oculta o membro herdado; nova palavra-chave ausente
        {
            try
            {
                return db.Compra.ToList();
            }
            catch { throw; }
        }


        // Filtra os registros com base na string de busca
#pragma warning disable CS0108 // O membro oculta o membro herdado; nova palavra-chave ausente
        public Compra GetFiltraCompra(int CompraNumero)
#pragma warning restore CS0108 // O membro oculta o membro herdado; nova palavra-chave ausente
        {
            try
            {
                Compra Compra = db.Compra.Find(CompraNumero);
                return Compra;
            }
            catch { throw; }
        }

#pragma warning disable CS0108 // O membro oculta o membro herdado; nova palavra-chave ausente
        public Task<int> SalvaCompra(String TituloCompra, int CompraItensQtd)
#pragma warning restore CS0108 // O membro oculta o membro herdado; nova palavra-chave ausente
        {
            var parameter = new List<SqlParameter>();
            parameter.Add(new SqlParameter("@TituloCompra", TituloCompra));
            parameter.Add(new SqlParameter("@CompraItensQtd", CompraItensQtd));


            var result = Task.Run(() => db.Database
           .ExecuteSqlRawAsync(@"exec dbo.sp_InsereCompra @TituloCompra, @CompraItensQtd", parameter.ToArray()));

            return result;





        }


#pragma warning disable CS0108 // O membro oculta o membro herdado; nova palavra-chave ausente
        public void CompraDeleta(int CompraNumero)
#pragma warning restore CS0108 // O membro oculta o membro herdado; nova palavra-chave ausente
        {
            try
            {
                Compra compra = db.Compra.Find(CompraNumero);
                db.Compra.Remove(compra);
                db.SaveChanges();
            }
            catch { throw; }
        }

#pragma warning disable CS0108 // O membro oculta o membro herdado; nova palavra-chave ausente
        public async Task<int> AtualizaCompra(Compra CompraNumero, Compra CompraData, Compra CompraTotal)
#pragma warning restore CS0108 // O membro oculta o membro herdado; nova palavra-chave ausente
        {
            var parameter = new List<SqlParameter>();
            parameter.Add(new SqlParameter("@CompraNumero", CompraNumero));
            parameter.Add(new SqlParameter("@CompraData", CompraData));
            parameter.Add(new SqlParameter("@CompraTotal", CompraTotal));
            var result = await Task.Run(() => db.Database
            .ExecuteSqlRawAsync(@"exec sp_EditaLista @CompraNumero, @CompraData, @CompraTotal", parameter.ToArray()));
            return result;


        }
    }
}
