﻿using Lista_de_Compra.Repositories.Interfaces;
using Lista_de_Compras.Context;
using Lista_de_Compras.Models;

namespace Lista_de_Compra.Repositories
{
    public class ProdutoCrud : IProdutoCrud
    {

        public readonly AppDbContext db;
        public ProdutoCrud(AppDbContext contexto)
        {
            db = contexto;
        }

        public IEnumerable<Produto> Index()

        {
            try
            {
                return db.Produto.ToList();
            }
            catch { throw; }
        }

#pragma warning disable CS0108 // O membro oculta o membro herdado; nova palavra-chave ausente
        public IEnumerable<Produto> Produtos()
#pragma warning restore CS0108 // O membro oculta o membro herdado; nova palavra-chave ausente
        {
            try
            {
                return db.Produto.ToList();
            }
            catch { throw; }
        }

        // Filtra os registros com base na string de busca
#pragma warning disable CS0108 // O membro oculta o membro herdado; nova palavra-chave ausente
        public Produto GetFiltraProduto(int ProdutoID)
#pragma warning restore CS0108 // O membro oculta o membro herdado; nova palavra-chave ausente
        {
            try
            {
                Produto Produto = db.Produto.Find(ProdutoID);
                return Produto;
            }
            catch { throw; }
        }



    }
}
