﻿using Lista_de_Compras.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Lista_de_Compras.ViewModels
{
    public class CompraListViewModel
    {
        public List<Produto> Produtos { get; set; }
        public List<CompraItens> CompraItens { get; set; }
        public List<Compra> Compra { get; set; }
        public Compra CompraNumero {  get; set; }
        public IEnumerable<Produto> ProdutoNome { get; set; }
        public IEnumerable<Produto> ProdutoID { get; set; }
        public IEnumerable<Produto> ProdutoUnidade { get; set; }
        
        public IEnumerable<CompraItens> CompraItensQtd { get; set; }
        public SelectList Prod { get; set; }
        public string Listaprod { get; set; }
        public string Filter { get; set; }
        

    }
}