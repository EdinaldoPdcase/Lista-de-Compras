﻿using Lista_de_Compras.Models;

namespace Lista_de_Compras
{
    public class CompraListViewModel
    {
        public Compra CompraTotal { get; set; }
        public CompraItens CompraItensQtd { get; set; }
        public Produto ProdutoNome { get; set; }
        public Produto ProdutoUnidade { get; set; }

    }
}