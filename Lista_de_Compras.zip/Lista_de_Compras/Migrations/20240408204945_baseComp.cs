﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ListadeCompras.Migrations
{
    /// <inheritdoc />
    public partial class baseComp : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Compra",
                columns: table => new
                {
                    CompraNumero = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CompraTitulo = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CompraData = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CompraTotal = table.Column<decimal>(type: "decimal(28,2)", nullable: false),
                    CompraSituacao = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Compra", x => x.CompraNumero);
                });

            migrationBuilder.CreateTable(
                name: "Produto",
                columns: table => new
                {
                    ProdutoID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProdutoNome = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ProdutoValorUnitario = table.Column<decimal>(type: "decimal(28,2)", nullable: false),
                    ProdutoUnidade = table.Column<string>(type: "nvarchar(3)", maxLength: 3, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Produto", x => x.ProdutoID);
                });

            migrationBuilder.CreateTable(
                name: "CompraItens",
                columns: table => new
                {
                    ProdutoID = table.Column<int>(type: "int", nullable: false),
                    CompraNumero = table.Column<int>(type: "int", nullable: false),
                    CompraItensQtd = table.Column<int>(type: "int", nullable: false),
                    CompraItensTotal = table.Column<decimal>(type: "decimal(28,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CompraItens", x => new { x.CompraNumero, x.ProdutoID });
                    table.ForeignKey(
                        name: "FK_CompraItens_Produto_ProdutoID",
                        column: x => x.ProdutoID,
                        principalTable: "Produto",
                        principalColumn: "ProdutoID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_CompraItens_ProdutoID",
                table: "CompraItens",
                column: "ProdutoID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Compra");

            migrationBuilder.DropTable(
                name: "CompraItens");

            migrationBuilder.DropTable(
                name: "Produto");
        }
    }
}
